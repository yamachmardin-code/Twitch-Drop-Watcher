package com.baroncold.dropwatcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String APP_URL = "https://yamachmardin-code.github.io/Twitch-Drop-Watcher/?source=android";
    private static final String PREFS = "drop_watcher_accounts";
    private static final String PREF_LIST = "profiles_json";
    private static final String PREF_CURRENT = "current_profile";

    private WebView webView;
    private FrameLayout webViewContainer;
    private FrameLayout fullscreenContainer;
    private LinearLayout accountBar;
    private TextView accountLabel;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private final List<AccountProfile> profiles = new ArrayList<>();
    private String currentProfileId;
    private boolean multiProfileSupported;

    static class AccountProfile {
        final String id;
        final String name;
        AccountProfile(String id, String name) { this.id = id; this.name = name; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webViewContainer = findViewById(R.id.webViewContainer);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);
        accountBar = findViewById(R.id.accountBar);
        accountLabel = findViewById(R.id.accountLabel);
        Button switchButton = findViewById(R.id.switchAccountButton);
        Button addButton = findViewById(R.id.addAccountButton);

        multiProfileSupported = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        loadProfiles();
        switchButton.setOnClickListener(v -> showAccountDialog());
        addButton.setOnClickListener(v -> showAddAccountDialog());
        configurePictureInPicture();
        createWebView();

        if (!multiProfileSupported) {
            addButton.setEnabled(false);
            switchButton.setEnabled(false);
            accountLabel.setText("Аккаунт: один профиль WebView");
            Toast.makeText(this, "Этот Android WebView не поддерживает раздельные профили. Обнови Android System WebView/Chrome.", Toast.LENGTH_LONG).show();
        }
    }

    private void loadProfiles() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = p.getString(PREF_LIST, "");
        try {
            if (raw != null && !raw.isEmpty()) {
                JSONArray a = new JSONArray(raw);
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    profiles.add(new AccountProfile(o.getString("id"), o.getString("name")));
                }
            }
        } catch (Exception ignored) { profiles.clear(); }
        if (profiles.isEmpty()) {
            profiles.add(new AccountProfile("account_1", "Аккаунт 1"));
            saveProfiles();
        }
        currentProfileId = p.getString(PREF_CURRENT, profiles.get(0).id);
        if (findProfile(currentProfileId) == null) currentProfileId = profiles.get(0).id;
    }

    private void saveProfiles() {
        JSONArray a = new JSONArray();
        try {
            for (AccountProfile ap : profiles) {
                JSONObject o = new JSONObject();
                o.put("id", ap.id); o.put("name", ap.name); a.put(o);
            }
        } catch (Exception ignored) { }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_LIST, a.toString()).putString(PREF_CURRENT, currentProfileId == null ? "account_1" : currentProfileId).apply();
    }

    private AccountProfile findProfile(String id) {
        for (AccountProfile p : profiles) if (p.id.equals(id)) return p;
        return null;
    }

    private void updateAccountLabel() {
        AccountProfile p = findProfile(currentProfileId);
        accountLabel.setText("Аккаунт: " + (p == null ? "?" : p.name));
    }

    private void createWebView() {
        destroyWebView();
        webView = new WebView(this);
        webViewContainer.removeAllViews();
        webViewContainer.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (multiProfileSupported) {
            try { WebViewCompat.setProfile(webView, currentProfileId); }
            catch (Exception e) { multiProfileSupported = false; }
        }
        configureWebView(webView);
        updateAccountLabel();
        webView.loadUrl(APP_URL);
    }

    private void configureWebView(WebView target) {
        WebSettings s = target.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        CookieManager cookies;
        if (multiProfileSupported) {
            try { cookies = WebViewCompat.getProfile(target).getCookieManager(); }
            catch (Exception e) { cookies = CookieManager.getInstance(); }
        } else { cookies = CookieManager.getInstance(); }
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(target, true);

        target.setBackgroundColor(Color.BLACK);
        target.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                if (host.equals("yamachmardin-code.github.io") || host.endsWith(".twitch.tv") || host.equals("twitch.tv") || host.endsWith(".twitchcdn.net")) return false;
                openExternal(uri);
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Toast.makeText(MainActivity.this, "WebView перезапущен после сбоя.", Toast.LENGTH_SHORT).show();
                createWebView();
                return true;
            }
        });

        target.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                if (!isUserGesture) return false;
                final WebView popup = new WebView(MainActivity.this);
                if (multiProfileSupported) {
                    try { WebViewCompat.setProfile(popup, currentProfileId); } catch (Exception ignored) { }
                }
                configurePopup(popup);
                AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).setView(popup).setNegativeButton("Закрыть", (d, which) -> d.dismiss()).create();
                dialog.setOnDismissListener(d -> popup.destroy());
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup); resultMsg.sendToTarget(); dialog.show(); return true;
            }

            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view; customViewCallback = callback;
                fullscreenContainer.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreenContainer.setVisibility(View.VISIBLE); webViewContainer.setVisibility(View.GONE); accountBar.setVisibility(View.GONE);
            }
            @Override public void onHideCustomView() {
                if (customView == null) return;
                fullscreenContainer.removeView(customView); fullscreenContainer.setVisibility(View.GONE); webViewContainer.setVisibility(View.VISIBLE);
                if (!isInPictureInPictureMode()) accountBar.setVisibility(View.VISIBLE);
                customView = null; if (customViewCallback != null) customViewCallback.onCustomViewHidden(); customViewCallback = null;
            }
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK", (d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show(); return true;
            }
        });
    }

    private void configurePopup(WebView popup) {
        WebSettings ps = popup.getSettings();
        ps.setJavaScriptEnabled(true); ps.setDomStorageEnabled(true); ps.setSupportMultipleWindows(true); ps.setMediaPlaybackRequiresUserGesture(true);
        ps.setAllowFileAccess(false); ps.setAllowContentAccess(false); ps.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager popupCookies;
        if (multiProfileSupported) {
            try { popupCookies = WebViewCompat.getProfile(popup).getCookieManager(); }
            catch (Exception e) { popupCookies = CookieManager.getInstance(); }
        } else { popupCookies = CookieManager.getInstance(); }
        popupCookies.setAcceptCookie(true);
        popupCookies.setAcceptThirdPartyCookies(popup, true);
        popup.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                Uri uri=request.getUrl(); String host=uri.getHost()==null?"":uri.getHost().toLowerCase();
                if(host.endsWith("twitch.tv")||host.equals("twitch.tv")||host.endsWith("twitchcdn.net")) return false;
                openExternal(uri); return true;
            }
        });
        popup.setWebChromeClient(new WebChromeClient());
    }

    private void showAccountDialog() {
        if (!multiProfileSupported) return;
        String[] names = new String[profiles.size()];
        for (int i=0;i<profiles.size();i++) names[i] = profiles.get(i).name + (profiles.get(i).id.equals(currentProfileId) ? "  ✓" : "");
        new AlertDialog.Builder(this)
                .setTitle("Twitch аккаунт-профиль")
                .setMessage("У каждого профиля отдельные cookies и история Drop Watcher. Переключение остановит текущий плеер.")
                .setItems(names, (d, which) -> switchProfile(profiles.get(which).id))
                .setPositiveButton("Добавить", (d,w) -> showAddAccountDialog())
                .setNegativeButton("Отмена", null)
                .show();
    }

    private void showAddAccountDialog() {
        if (!multiProfileSupported) return;
        EditText input = new EditText(this); input.setHint("Например: Второй аккаунт / Друг"); input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Новый профиль").setView(input)
                .setPositiveButton("Создать", (d,w) -> {
                    String name=input.getText().toString().trim(); if(name.isEmpty()) name="Аккаунт "+(profiles.size()+1);
                    String id="account_"+System.currentTimeMillis(); profiles.add(new AccountProfile(id,name)); currentProfileId=id; saveProfiles(); createWebView();
                    Toast.makeText(this,"Профиль создан. Теперь войди в нужный Twitch аккаунт.",Toast.LENGTH_LONG).show();
                }).setNegativeButton("Отмена",null).show();
    }

    private void switchProfile(String id) {
        if (id.equals(currentProfileId)) return;
        currentProfileId=id; saveProfiles(); createWebView();
        Toast.makeText(this,"Профиль переключен. Проверь, какой Twitch аккаунт вошел в плеер.",Toast.LENGTH_LONG).show();
    }

    private void configurePictureInPicture() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        PictureInPictureParams.Builder b = new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) b.setAutoEnterEnabled(true).setSeamlessResizeEnabled(true);
        setPictureInPictureParams(b.build());
    }

    private void openExternal(Uri uri) { try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { } }

    @Override public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && Build.VERSION.SDK_INT < Build.VERSION_CODES.S && !isInPictureInPictureMode()) {
            try { enterPictureInPictureMode(new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build()); } catch (Exception ignored) { }
        }
    }

    @Override public void onPictureInPictureModeChanged(boolean inPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(inPip, newConfig);
        accountBar.setVisibility(inPip ? View.GONE : View.VISIBLE);
        if (webView != null) webView.evaluateJavascript("window.setDropWatcherPipMode && window.setDropWatcherPipMode(" + (inPip ? "true" : "false") + ");", null);
    }

    @Override public void onBackPressed() {
        if (customView != null && webView != null) webView.getWebChromeClient().onHideCustomView();
        else if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private void destroyWebView() {
        if (webView != null) {
            try {
                if (multiProfileSupported) WebViewCompat.getProfile(webView).getCookieManager().flush();
                else CookieManager.getInstance().flush();
            } catch (Exception ignored) { }
            webView.stopLoading(); webViewContainer.removeView(webView); webView.destroy(); webView=null;
        }
    }

    @Override protected void onDestroy() { destroyWebView(); super.onDestroy(); }
}
